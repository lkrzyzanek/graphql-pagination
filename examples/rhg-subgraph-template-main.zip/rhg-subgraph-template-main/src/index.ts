import * as dotenv from 'dotenv';
// Loads environment variables from .env file into process.env object
dotenv.config();

import { getLogger } from '@rhg/utils-base/logger';
import otelInit from './otel';
import { serverInit } from './server';

// Initializing the Opentelemetry instrumentation.
otelInit();

// Setting the module name for logging.
const log = getLogger('index');

async function main() {
  try {
    // Initalizing the Subgraph Server.
    const rhgServer = await serverInit();
    log.info(
      `Red Hat Subgraph (powered by Apollo Server & NodeJS ${process.version}) ready at ${rhgServer.url}`
    );
  } catch (err) {
    log.error(`Error starting server: ${err.message}`);
    process.exit(1);
  }
}

main();
