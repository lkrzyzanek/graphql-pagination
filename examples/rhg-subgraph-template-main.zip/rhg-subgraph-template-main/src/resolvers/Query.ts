import { Resolvers } from '../__generated__/resolversTypes';

export const Query: Resolvers = {
  Query: {
    books: async (_, args, { booksApi }) => {
      return await booksApi.forwardResolver(args);
    },
  },
};
