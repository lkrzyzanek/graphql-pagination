import { subgraphServer } from '../server';
import { queryApolloServer } from '@rhg/utils-base/test-utils';
import { Query } from '../__generated__/resolversTypes';

describe('Schema Tests', () => {
  const gqlQuery = /* GraphQL */ `
    query TypeName {
      __typename
    }

    query Service {
      _service {
        sdl
      }
    }
  `;
  afterAll(async () => {
    // Close any resources used by the server after all tests are completed
    await subgraphServer.stop();
  });

  it('should return the typename as "Query"', async () => {
    const result = await queryApolloServer<Query>(subgraphServer, {
      query: gqlQuery,
      operationName: 'TypeName',
    });
    expect(result.errors).toBeUndefined();
    expect(result.data.__typename).toBe('Query');
  });
});
