import { Query } from './Query';
import { Resolvers } from '../__generated__/resolversTypes';

const resolvers: Resolvers = {
  ...Query,
};

export default resolvers;
