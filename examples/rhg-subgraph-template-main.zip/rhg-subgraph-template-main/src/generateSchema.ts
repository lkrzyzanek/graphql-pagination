import { saveSchema } from '@rhg/subgraph-server';
import { getLogger } from '@rhg/utils-base/logger';
import { subgraphServer } from './server';

const log = getLogger('generateSchema');

async function generateSchema() {
  saveSchema(subgraphServer, 'schema-full.graphql').catch((err) => {
    log.error(`Error saving schema: ${err.message}`);
    process.abort();
  });
}

generateSchema();
