import { mergeTypeDefs } from '@graphql-tools/merge';
import { defaultDirectives } from '@rhg/subgraph-server';
import pager from '../datasources/booksApi';
import schemaTypeDefs from './schema.gql';

const typeDefs = mergeTypeDefs([schemaTypeDefs, pager.typeDefs, ...defaultDirectives()]);

export default typeDefs;
