import { AuthContext } from '@rhg/subgraph-server';
import booksApi from '../datasources/booksApi';

//This interface is used with graphql-codegen to generate types for resolvers context
export interface DataSourceContext extends AuthContext {
  booksApi: typeof booksApi;
}
