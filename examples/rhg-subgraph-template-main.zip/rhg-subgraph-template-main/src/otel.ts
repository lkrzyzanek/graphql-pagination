import { init } from '@rhg/utils-base/otel';
import { getLogger } from '@rhg/utils-base/logger';

const log = getLogger('otel');

/* init([]) function takes an array of configurations to enable the instrumentation.
    Example packages
    @opentelemetry/instrumentation-mysql2, @opentelemetry/instrumentation-mongodb
*/
export default function otelInit() {
  log.info('Initializing OpenTelemetry for Subgraph');
  init([]);
}
