/*
 * For a detailed explanation regarding each configuration property, visit:
 * https://jestjs.io/docs/configuration
 */

import type { Config } from 'jest';

const config: Config = {
  verbose: true,
  preset: 'ts-jest',
  reporters: ['jest-junit', 'default'],
  roots: ['src'],
  testPathIgnorePatterns: ['mock.ts'],
  collectCoverage: true,
  coverageDirectory: 'coverage',
  collectCoverageFrom: ['src/**/*.ts', '!src/generate*.ts'],
  coverageReporters: ['text', 'text-summary', 'cobertura', 'lcov'],
  setupFilesAfterEnv: ['@rhg/utils-base/jest-log-format'],
};

export default config;
