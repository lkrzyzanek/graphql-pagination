const conf = require('@rhg/schema-linter').configuration;

// local extensions of the shared configuration, eg. ignores. Keep them documented!
// conf.ignore["relay-connection-required"].push("Query.products_metadata");

// use of query-cost-required check which is not in the default config because relevant for Gateway only
// conf.rules.push("query-cost-required");
// path to the costs configuration file
// conf.rulesOptions["query-cost-required"] = "../src/query-protections-cost-map.json";
// conf.ignore["query-cost-required"]=["Query.products_metadata"];

module.exports = conf;
