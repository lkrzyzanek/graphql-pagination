import { subgraphServer } from '../server';
import { getResponseBodySingleResult } from '@rhg/utils-base/test-utils';
import { Query } from '../__generated__/resolversTypes';
import { books } from './mocks/books.mock';
import { ArrayDataSource, dataSourcePager } from '@graphql-pagination/core';

describe('Books GraphQL API', () => {
  const gqlQuery = /* GraphQL */ `
    query Books($after: String, $first: Int) {
      books(after: $after, first: $first) {
        edges {
          cursor
          node {
            id
            title
            author
          }
        }
      }
    }
  `;

  const executeOptions = {
    contextValue: {
      booksApi: dataSourcePager({ dataSource: new ArrayDataSource(books) }),
    },
  };

  afterAll(async () => {
    // Close any resources used by the server after all tests are completed
    await subgraphServer.stop();
  });

  it('should return a list of books with valid cursor and book details when querying for books', async () => {
    const result = await subgraphServer
      .executeOperation<Query>(
        {
          query: gqlQuery,
          operationName: 'Books',
        },
        executeOptions
      )
      .then(getResponseBodySingleResult);
    expect(result.errors).toBeUndefined();
    expect(result.data.books.edges).toBeDefined();
    expect(result.data.books.edges[0].cursor).toBeDefined();
    expect(result.data.books.edges[0].node).toEqual(books[0]);
  });
});
