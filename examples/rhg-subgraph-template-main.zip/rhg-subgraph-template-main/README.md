# RHG Subgraph Server

This is a starter template for building a subgraph.

## Getting started

### Prerequisites

- [NodeJS](https://nodejs.org/) version 18 or later
- [pnpm](https://pnpm.io)

### Installation

1.  Form and clone this repository:

```console
git clone https://gitlab.cee.redhat.com/dxp/rhg-subgraphs/rhg-subgraph-template.git
cd rhg-subgraph-template
```

2.  Form and clone this repository:

```console
pnpm install
```

### Configuration

The server can be configured using environment variables. Copy the `.env.example` as `.env` file and add the required values.

### Development

To start the server in development mode, run:

```console
pnpm dev
```

This will start the server using nodemon, which will automatically restart the server whenever you make changes to the code.

### Production

To build and start the server in production mode, run:

```console
pnpm build
pnpm start
```

### Testing

To run the tests, run:

```console
pnpm test
```

## Versioning
It's important to version your subgraph so that users can easily track changes and compatibility. We use semantic versioning for versioning this subgraph.

Each version number consists of three parts: major.minor.patch. Here's what each part means:

**Major version**: A major version change indicates a breaking change, meaning that users may need to modify their code to use the new version.

**Minor version**: A minor version change indicates a new feature has been added, but it is still backward-compatible.

**Patch version**: A patch version change indicates a bug fix or other small change that is backward-compatible.
When making changes to your subgraph, update the version number in your `package.json` and `Dockerfile` file accordingly. If you're making a breaking change, be sure to update the major version number. If you're adding a new feature, update the minor version number. If you're making a bug fix or small change, update the patch version number.

For example, if you're currently at version `1.0.0` and you make a breaking change, you would update the version number to `2.0.0`. If you instead added a new feature, you would update the version number to `1.1.0`. If you fixed a bug, you would update the version number to `1.0.1`.

### Deployment
We are using [Red Hat GraphQL CI/CD Templates](https://gitlab.cee.redhat.com/cdx/graphql/common/templates) for the deployment.

## Author
[Rigin Oommen](mailto:roommen@redhat.com)
