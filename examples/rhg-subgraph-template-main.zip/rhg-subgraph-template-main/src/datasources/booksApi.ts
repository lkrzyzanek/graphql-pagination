import { dataSourcePager, ArrayDataSource } from '@graphql-pagination/core';

const books = [
  {
    id: '1',
    title: 'Angels & Demons',
    author: 'Rigin Oommen',
  },
  {
    id: '2',
    title: 'Two States',
    author: 'Navinya Shende',
  },
  {
    id: '3',
    title: '3 Idiots',
    author: 'Akhil Mohan',
  },
];

const dataSource = new ArrayDataSource(books);

const pager = dataSourcePager({
  dataSource: dataSource,
  typeName: 'Book',
  fetchTotalCountInResolver: true,
  typeDefDirectives: {
    edge: '@cacheControl(inheritMaxAge: true)',
    pageInfo: '@cacheControl(inheritMaxAge: true) @shareable',
    connection: '@cacheControl(inheritMaxAge: true)',
  },
});

export default pager;
