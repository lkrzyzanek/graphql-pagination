import { ServerInfo } from '@rhg/subgraph-server';
import { serverInit } from '../server';

describe('RHG Subgraph Server', () => {
  let subgraphServer: ServerInfo;

  beforeEach(() => {
    // Setting SERVER_PORT environment variable before each test case
    process.env.SERVER_PORT = '0';
  });

  afterAll(async () => {
    // Close any resources used by the server after all tests are completed
    await subgraphServer.server.close();
  });

  // Testing if the subgraph server starts successfully
  it('should successfully initialize and start the subgraph server at the expected URL', async () => {
    // Initializing the server and storing the server info in subgraphServer variable
    subgraphServer = await serverInit();
    // Asserting that the server URL is defined and matches the expected URL
    expect(subgraphServer.url).toBeDefined();
    expect(subgraphServer.port).not.toBe(4000);
    expect(subgraphServer.url).toContain(`http://localhost:${subgraphServer.port}`);
  });
});
