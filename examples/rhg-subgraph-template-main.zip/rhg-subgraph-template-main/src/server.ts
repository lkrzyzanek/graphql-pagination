// Importing required modules
import { buildSubgraphSchema } from '@apollo/subgraph';
import { SubgraphAuthenticator } from '@rhg/auth';
import { RhgSubgraphServer, startStandaloneServer } from '@rhg/subgraph-server';
import { getLogger } from '@rhg/utils-base/logger';
import { SourceFieldDirective } from '@rhg/utils-base/directives';
import booksApi from './datasources/booksApi';

// Importing the typedefs and resolver functions
import resolvers from './resolvers';
import typeDefs from './typeDefs';
import { DataSourceContext } from './types/DataSourceContext';

// Creating a logger object
const log = getLogger('server');

// Building the schema using the typedefs and resolver functions
let schema = buildSubgraphSchema({ typeDefs, resolvers });
schema = SourceFieldDirective.transformSchema(schema);

// Creating a new RhgSubgraphServer instance with the parsed schema and resolver functions
const subgraphServer: RhgSubgraphServer<unknown> = new RhgSubgraphServer({
  schema,
});

async function serverInit() {
  // Creating a new SubgraphAuthenticator instance for authenticating GraphQL requests.
  const authenticator = new SubgraphAuthenticator();

  let port = 4000;
  if (process.env.SERVER_PORT) port = Number.parseInt(process.env.SERVER_PORT);

  // Starting a standalone server using the RhgSubgraphServer instance
  const standAloneServer = await startStandaloneServer<DataSourceContext>(subgraphServer, {
    listen: {
      port,
    },
    keepAliveTimeout: 20000, // 20 sec keep alive
    timeout: 50000, // 50 sec (openshift route has 60 sec)
    context: async ({ req }) => {
      try {
        const res = await authenticator.authenticate(req.headers);
        return {
          booksApi,
          ...res,
        };
      } catch (err) {
        log.error(`Error authenticating request: ${err.message}`);
        throw err;
      }
    },
  }).catch((err) => {
    log.error(`Error starting server: ${err.message}`);
    process.exit(1);
  });
  return standAloneServer;
}

export { serverInit, subgraphServer };
