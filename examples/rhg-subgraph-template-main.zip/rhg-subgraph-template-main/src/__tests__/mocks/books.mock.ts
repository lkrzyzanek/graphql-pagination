export const books = [
  {
    id: '1',
    title: 'Angels & Demons',
    author: 'Rigin Oommen',
  },
  {
    id: '2',
    title: 'Two States',
    author: 'Navinya Shende',
  },
  {
    id: '3',
    title: '3 Idiots',
    author: 'Akhil Mohan',
  },
];
